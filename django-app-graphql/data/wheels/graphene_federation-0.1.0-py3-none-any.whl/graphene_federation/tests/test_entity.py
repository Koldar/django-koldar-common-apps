# test resolve_entities method
